import mongoose from "mongoose";

const itemSchema = new mongoose.Schema({
    id:{
        type:String,
        required:true,
        trim:true,
    },
    name:{
        type:String,
        required:true,
        trim:true,
    },
    quantity:{
        type:Number,
        required:true,
        min:[1,'quantity cannot be less than 1']
    },
    price:{
        type:Number,
        required:true,
    }
})

const cartSchema =new mongoose.Schema({
    item:itemSchema,
    active:{
        type:Boolean,
        default:false,
    },
    modifiedOn:{
        type:Date,
        default:Date.now
    }
},
{timestamps:true}
)

const Cart=mongoose.model("cart",cartSchema)
export default Cart